#!/usr/bin/env python3
"""Floorp Modern: userChrome.css layer (browser UI) + userContent.css layer (about: pages)."""

def svg(body, fill=False, sw="2.1"):
    attrs = ("fill='context-fill'" if fill else
             f"fill='none' stroke='context-fill' stroke-width='{sw}' stroke-linecap='round' stroke-linejoin='round'")
    return ("url(\"data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' "
            + attrs + ">" + body + "</svg>\")")

P = lambda d: f"<path d='{d}'/>"

ICONS = {
    "#back-button": svg(P("M19 12H5") + P("M11 6l-6 6 6 6")),
    "#forward-button": svg(P("M5 12h14") + P("M13 6l6 6-6 6")),
    "#reload-button": svg(P("M20 12a8 8 0 1 1-2.35-5.65") + P("M20 4v5h-5")),
    "#stop-button": svg(P("M6 6l12 12M18 6L6 18")),
    "#home-button": svg(P("M4 10.5L12 4l8 6.5V19a1.5 1.5 0 0 1-1.5 1.5H15v-6H9v6H5.5A1.5 1.5 0 0 1 4 19z")),
    "#downloads-button": svg(P("M12 3.5v11") + P("M7 10l5 5 5-5") + P("M4.5 20h15")),
    "#PanelUI-menu-button": svg(P("M4 7h16M4 12h16M4 17h16")),
    "#unified-extensions-button": svg(P("M9.5 4.5a2 2 0 0 1 4 0V6H17a1 1 0 0 1 1 1v3.5h1.5a2 2 0 0 1 0 4H18V18a1 1 0 0 1-1 1h-3.5v-1.5a2 2 0 0 0-4 0V19H6a1 1 0 0 1-1-1v-3.5h1.5a2 2 0 0 0 0-4H5V7a1 1 0 0 1 1-1h3.5z")),
    "#sidebar-button": svg("<rect x='3' y='4' width='18' height='16' rx='3.5'/>" + P("M9.5 4v16")),
    "#new-tab-button, #tabs-newtab-button, #vertical-tabs-newtab-button": svg(P("M12 5v14M5 12h14")),
    "#alltabs-button": svg(P("M7 10l5 5 5-5")),
    "#PlacesChevron": svg(P("M7 7l5 5-5 5M13 7l5 5-5 5")),
    "#fxa-toolbar-menu-button": svg("<circle cx='12' cy='8.5' r='3.5'/>" + P("M5 19.5c1.3-3.3 4-5 7-5s5.7 1.7 7 5")),
    "#bookmarks-menu-button": svg(P("M7 3.5h10v17l-5-4-5 4z")),
    "#history-panelmenu": svg("<circle cx='12' cy='12' r='8.5'/>" + P("M12 7.5V12l3 2")),
    "#print-button": svg(P("M7 9V3.5h10V9") + "<rect x='3.5' y='9' width='17' height='8' rx='2.5'/>" + P("M7 14h10v6.5H7z")),
    "#screenshot-button": svg(P("M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2")),
    "#developer-button": svg(P("M9 8l-4 4 4 4M15 8l4 4-4 4")),
    "#preferences-button": svg("<circle cx='12' cy='12' r='3'/>" + P("M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z")),
}

icon_rules = "\n".join(
    f"  :is({sel}) {{ list-style-image: {url} !important; }}" for sel, url in ICONS.items()
)

TOKENS = r"""
  /* ---------- НАСТРОЙКИ: меняйте тут ---------- */
  /* цвет акцента берётся из Windows (Параметры > Персонализация > Цвета) */
  --fm-accent: light-dark(AccentColor, color-mix(in srgb, AccentColor 62%, white));
  --fm-on-accent: light-dark(AccentColorText, color-mix(in srgb, AccentColor 22%, black));
  --fm-radius: 22px;          /* скругление карточки со страницей */
  --fm-gap: 8px;              /* отступ вокруг карточки */
  /* -------------------------------------------- */

  --fm-frame:  light-dark(#f2f3f5, #000000);
  --fm-bar:    light-dark(#ffffff, #17181a);
  --fm-field:  light-dark(#ffffff, #1f2022);
  --fm-line:   light-dark(rgb(0 0 0 / .07), rgb(255 255 255 / .07));
  --fm-ink:    light-dark(#111214, #f2f2f3);
  --fm-muted:  light-dark(#6b6f76, #9a9da3);
  --fm-hover:  light-dark(rgb(0 0 0 / .05), rgb(255 255 255 / .08));
  --fm-press:  light-dark(rgb(0 0 0 / .10), rgb(255 255 255 / .14));
  --fm-soft:   color-mix(in srgb, var(--fm-accent) 17%, transparent);
  --fm-glass:  light-dark(rgb(255 255 255 / .78), rgb(36 37 40 / .72));
  --fm-shine:  inset 0 1px 0 light-dark(rgb(255 255 255 / .95), rgb(255 255 255 / .07));
  --fm-pop:    0 4px 10px light-dark(rgb(0 0 0 / .06), rgb(0 0 0 / .45)),
               0 22px 56px light-dark(rgb(0 0 0 / .14), rgb(0 0 0 / .65));
  --fm-card:   0 1px 3px light-dark(rgb(0 0 0 / .05), rgb(0 0 0 / .6)),
               0 10px 30px light-dark(rgb(0 0 0 / .06), rgb(0 0 0 / .4));
  --fm-font:   "Segoe UI Variable Display", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif;
"""

CHROME = r"""
/* ======================= FLOORP-MODERN BEGIN ======================= */
/* Floorp Modern · стиль Samsung One UI 8.5.
   Блок ставит и убирает установщик. Правки внутри пропадут при переустановке. */

:root {
@TOKENS@
  --color-accent-primary: var(--fm-accent) !important;
  --color-accent-primary-hover: color-mix(in srgb, var(--fm-accent) 88%, var(--fm-ink)) !important;
  --color-accent-primary-active: color-mix(in srgb, var(--fm-accent) 76%, var(--fm-ink)) !important;
  --focus-outline-color: var(--fm-accent) !important;
  --toolbar-field-focus-border-color: var(--fm-accent) !important;
  --toolbarbutton-border-radius: 999px !important;
  --tab-border-radius: 999px !important;
  --tab-background-color-hover: var(--fm-hover) !important;
  --chrome-block-radius: var(--fm-radius) !important;
  --border-radius-medium: 14px !important;
  --panel-border-radius: 26px !important;
  --arrowpanel-border-radius: 26px !important;
  --arrowpanel-menuitem-border-radius: 16px !important;
  --menuitem-border-radius: 14px !important;
  --panel-shadow: var(--fm-pop) !important;
  --urlbarview-border-radius: 26px !important;
}

#navigator-toolbox, #sidebar-main, #panel-sidebar-select-box, menupopup, panel, tooltip {
  font-family: var(--fm-font) !important;
}

/* ---------- фон окна: чистый чёрный / светло-серый, как в One UI ---------- */
:root:not([lwtheme]) {
  --toolbox-background-color: var(--fm-frame) !important;
  --toolbox-background-color-inactive: var(--fm-frame) !important;
  --toolbar-background-color: var(--fm-frame) !important;
  --toolbar-bgcolor: var(--fm-frame) !important;
  --sidebar-background-color: var(--fm-frame) !important;
  --panel-sidebar-background-color: var(--fm-frame) !important;
  --toolbox-background-image: none !important;
}
:root:not([lwtheme]) :is(#navigator-toolbox, #nav-bar, #PersonalToolbar, #TabsToolbar, #browser, #sidebar-main, #sidebar-box, #panel-sidebar-select-box, #nora-statusbar) {
  background-color: var(--fm-frame) !important;
  background-image: none !important;
}
#navigator-toolbox { border-bottom: 0 !important; }
#nav-bar { box-shadow: none !important; border-top: 0 !important; padding-block: 4px !important; }

/* ---------- карточка со страницей ---------- */
:root:not([inDOMFullscreen], [inFullscreen]) #tabbrowser-tabbox {
  padding: 0 var(--fm-gap) var(--fm-gap) !important;
  background: transparent !important;
  box-shadow: none !important;
  outline: none !important;
}
:root:not([inDOMFullscreen], [inFullscreen]) #tabbrowser-tabpanels .browserContainer {
  border-radius: var(--fm-radius) !important;
  overflow: clip !important;
  border: 0 !important;
  box-shadow: var(--fm-card) !important;
  outline: none !important;
}
#tabbrowser-tabpanels { background: transparent !important; }

/* ---------- кнопки: круглые, с мягким «объёмом» ---------- */
toolbar .toolbarbutton-1 {
  --toolbarbutton-hover-background: var(--fm-hover) !important;
  --toolbarbutton-active-background: var(--fm-press) !important;
}
toolbar .toolbarbutton-1 > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack, .toolbarbutton-text) {
  border-radius: 999px !important;
}
toolbar .toolbarbutton-1[disabled] { opacity: .3 !important; }
toolbarbutton:is([open], [checked]) > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack) {
  background-color: var(--fm-soft) !important;
  fill: var(--fm-accent) !important;
}

@ICONS@

/* ---------- адресная строка: «таблетка» ---------- */
#urlbar {
  --toolbar-field-background-color: var(--fm-frame) !important;
  --toolbar-field-focus-background-color: var(--fm-frame) !important;
  --toolbar-field-border-color: transparent !important;
  --urlbar-min-height: 36px !important;
}
#urlbar-background, .urlbar-background {
  border-radius: 999px !important;
  background-color: color-mix(in srgb, currentColor 9%, var(--toolbar-field-background-color, transparent)) !important;
  border: 0 !important;
  box-shadow: var(--fm-shine), 0 1px 3px light-dark(rgb(0 0 0 / .08), rgb(0 0 0 / .5)) !important;
}
#urlbar[fm-unused-legacy] > :is(#urlbar-background, .urlbar-background) {
  outline: 2px solid var(--fm-accent) !important;
  outline-offset: -1px !important;
}
#urlbar[open] > :is(#urlbar-background, .urlbar-background) {
  border-radius: 26px !important;
}
#urlbar-input { font-size: 14px !important; }
#urlbar-input-container { padding-inline: 6px !important; }
.urlbarView-row, .urlbarView-row-inner { border-radius: 16px !important; }
.urlbarView-row[selected] > .urlbarView-row-inner {
  background-color: var(--fm-soft) !important;
  color: inherit !important;
}
.urlbarView-row[selected] :is(.urlbarView-title, .urlbarView-url, .urlbarView-action) { color: inherit !important; }
#identity-box, #tracking-protection-icon-container, .searchmode-switcher, #urlbar-searchmode-switcher,
#identity-icon-box, #identity-permission-box, .urlbar-page-action {
  border-radius: 999px !important;
}

/* ---------- вкладки: «таблетки» ---------- */
.tabbrowser-tab > .tab-stack > .tab-background {
  border-radius: 999px !important;
  outline: none !important;
}
.tabbrowser-tab[selected] > .tab-stack > .tab-background,
.tabbrowser-tab[multiselected] > .tab-stack > .tab-background {
  background: var(--fm-soft) !important;
  box-shadow: none !important;
}
.tabbrowser-tab[selected] .tab-label { color: var(--fm-accent) !important; }
.tabbrowser-tab:not([selected]):hover > .tab-stack > .tab-background { background: var(--fm-hover) !important; }
.tab-label { font-size: 13px !important; }
.tab-close-button { border-radius: 999px !important; }
.tab-close-button:hover { background: var(--fm-hover) !important; }
.tab-throbber, .tab-loading-burst { color: var(--fm-accent) !important; }

/* ---------- закладки: «таблетки» ---------- */
#PersonalToolbar { padding-block: 0 6px !important; }
#PlacesToolbarItems > .bookmark-item, #PersonalToolbar .toolbarbutton-1 {
  border-radius: 999px !important;
  padding: 5px 11px !important;
  margin-inline: 2px !important;
}
/* цвет «таблеток» считается от цвета текста: так он всегда верный,
   даже если при запуске Floorp на миг считает тему светлой */
#PlacesToolbarItems > .bookmark-item {
  background: color-mix(in srgb, currentColor 9%, transparent) !important;
  box-shadow: inset 0 1px 0 color-mix(in srgb, currentColor 7%, transparent) !important;
}
#PlacesToolbarItems > .bookmark-item:hover { background: color-mix(in srgb, currentColor 15%, transparent) !important; }
#PlacesToolbarItems > .bookmark-item[open] { background: var(--fm-soft) !important; color: var(--fm-accent) !important; }
#PlacesToolbarItems > .bookmark-item > .toolbarbutton-text { font-size: 12.5px !important; font-weight: 500 !important; }
#PlacesToolbarItems > toolbarseparator { display: none !important; }

/* ---------- боковая панель сайтов Floorp ----------
   Без обрезки, теней и анимаций: внутри панели живая веб-страница,
   и такие эффекты заставляют её перерисовываться (тормоза). */
#panel-sidebar-select-box { border-inline: 0 !important; }
.panel-sidebar-panel, .panel-sidebar-actions {
  border-radius: 999px !important;
  box-shadow: none !important;
}
.panel-sidebar-panel:hover, .panel-sidebar-actions:hover {
  background-color: var(--fm-hover) !important;
  box-shadow: none !important;
}
.panel-sidebar-panel[data-checked="true"] {
  background-color: var(--fm-soft) !important;
  box-shadow: none !important;
}
#panel-sidebar-box, #panel-sidebar-header {
  background: var(--fm-bar) !important;
  background-image: none !important;
}
#panel-sidebar-splitter, #sidebar-splitter { border: 0 !important; }

/* ---------- меню: крупные карточки ---------- */
menupopup, panel {
  --panel-background: var(--fm-bar) !important;
  --panel-color: var(--fm-ink) !important;
  --panel-border-color: var(--fm-line) !important;
  --panel-padding: 8px !important;
  --menuitem-padding: 8px 14px !important;
  --arrowpanel-background: var(--fm-bar) !important;
  --arrowpanel-color: var(--fm-ink) !important;
  --arrowpanel-border-color: var(--fm-line) !important;
  --arrowpanel-dimmed: var(--fm-hover) !important;
  --arrowpanel-dimmed-further: var(--fm-press) !important;
  --panel-item-hover-bgcolor: var(--fm-hover) !important;
  --panel-item-active-bgcolor: var(--fm-press) !important;
}
menupopup > :is(menuitem, menu) { border-radius: 14px !important; min-height: 36px !important; }
menupopup > :is(menuitem, menu):is([_moz-menuactive], :hover):not([disabled]) {
  background-color: var(--fm-hover) !important;
  color: inherit !important;
}
menupopup > menuseparator { opacity: .4 !important; margin-inline: 14px !important; }
.subviewbutton { border-radius: 16px !important; min-height: 38px !important; }
.subviewbutton:not([disabled]):hover { background-color: var(--fm-hover) !important; }
.panel-footer > button, button.primary, .popup-notification-primary-button,
.popup-notification-secondary-button, .footer-button {
  border-radius: 999px !important;
}
button.primary, .popup-notification-primary-button {
  background-color: var(--fm-accent) !important;
  color: var(--fm-on-accent) !important;
}
tooltip {
  appearance: none !important;
  background: var(--fm-bar) !important;
  color: var(--fm-ink) !important;
  border: 1px solid var(--fm-line) !important;
  border-radius: 999px !important;
  padding: 6px 12px !important;
}

/* ---------- мелочи ---------- */
.toolbarbutton-badge {
  background-color: var(--fm-accent) !important;
  color: var(--fm-on-accent) !important;
  box-shadow: none !important;
  border-radius: 999px !important;
}
#nav-bar toolbarspring { max-width: 64px !important; }
findbar { border-top: 0 !important; background: var(--fm-frame) !important; }
findbar .findbar-textbox { border-radius: 999px !important; }
.notificationbox-stack notification-message, .infobar { border-radius: 18px !important; }

@media (prefers-reduced-motion: reduce) {
  * { transition: none !important; }
}

/* ======== ВАУ-СЛОЙ: живость One UI 8.5 ======== */
/* контекстные меню раскрываются с мягкой «пружинкой» */

/* кнопки отвечают на нажатие, как в One UI: чуть «проседают» */
toolbar .toolbarbutton-1 > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack) {
  transition: background-color .2s ease, scale .28s cubic-bezier(.3, 1.6, .5, 1) !important;
}
toolbar .toolbarbutton-1:not([disabled]):active > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack) { scale: .88; }
#PlacesToolbarItems > .bookmark-item { transition: background-color .2s ease, scale .25s cubic-bezier(.3, 1.6, .5, 1) !important; }
#PlacesToolbarItems > .bookmark-item:active { scale: .94; }

/* адрес по центру, пока строка не в фокусе — как в Samsung Internet */
#urlbar:not([focused], [open]) #urlbar-input,
moz-urlbar:not([focused], [open]) .urlbar-input { text-align: center !important; }
#urlbar { --urlbar-min-height: 38px !important; }

/* вкладки: значок слегка подпрыгивает при наведении, активная — жирнее */
.tabbrowser-tab .tab-icon-image { transition: scale .25s cubic-bezier(.3, 1.6, .5, 1) !important; }
.tabbrowser-tab:hover .tab-icon-image { scale: 1.12; }
.tabbrowser-tab[selected] .tab-label { font-weight: 600 !important; }

/* заголовки панелей крупные, как в One UI */
.panel-header { justify-content: flex-start !important; padding-inline: 16px !important; }
.panel-header > h1 { font-size: 19px !important; font-weight: 700 !important; letter-spacing: -0.01em !important; }

/* режим фокуса (Alt+Shift+Z): прячет закладки и боковые панели */
:root[fm-focus] :is(#PersonalToolbar, #sidebar-main, #sidebar-box, #panel-sidebar-select-box, #panel-sidebar-box, #sidebar-splitter, #panel-sidebar-splitter) {
  visibility: collapse !important;
}

/* «Now Bar»: музыка из другой вкладки — плашка внизу, как на Galaxy */
.fm-nowbar {
  position: absolute; left: 50%; bottom: 16px; z-index: 1001;
  display: flex; align-items: center; gap: 4px;
  max-width: min(460px, calc(100% - 40px));
  padding: 6px 6px 6px 8px; border-radius: 999px;
  background: var(--fm-bar); color: var(--fm-ink);
  border: 1px solid var(--fm-line);
  box-shadow: var(--fm-shine), var(--fm-pop);
  font: 500 13px var(--fm-font);
  opacity: 0; translate: -50% 18px; scale: .96;
  pointer-events: none;
  transition: opacity .25s ease, translate .4s cubic-bezier(.2, .9, .25, 1.15), scale .4s cubic-bezier(.2, .9, .25, 1.15);
}
.fm-nowbar.fm-in { opacity: 1; translate: -50% 0; scale: 1; pointer-events: auto; }
.fm-nowbar-eq {
  flex: none; width: 30px; height: 30px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center; gap: 2px;
  background: var(--fm-accent);
}
.fm-nowbar-eq > span {
  width: 3px; height: 12px; border-radius: 2px; background: var(--fm-on-accent);
  transform-origin: 50% 100%;
  animation: fm-eq .9s ease-in-out infinite alternate;
}
.fm-nowbar-eq > span:nth-child(2) { animation-delay: -.3s; }
.fm-nowbar-eq > span:nth-child(3) { animation-delay: -.6s; }
.fm-nowbar[data-paused] .fm-nowbar-eq > span { animation: none; transform: scaleY(.35); }
@keyframes fm-eq { from { transform: scaleY(.3); } to { transform: scaleY(1); } }
.fm-nowbar-title {
  flex: 1; min-width: 0; padding: 0 8px; cursor: pointer;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.fm-nowbar-title:hover { color: var(--fm-accent); }
.fm-nowbar-btn {
  flex: none; width: 30px; height: 30px; border-radius: 50%; cursor: pointer;
  background: center / 16px no-repeat; -moz-context-properties: fill; fill: currentColor;
}
.fm-nowbar-btn:hover { background-color: var(--fm-hover); }
.fm-nowbar-btn:active { background-color: var(--fm-press); }
.fm-nowbar-play { background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='context-fill'><rect x='6.5' y='5' width='4' height='14' rx='1.5'/><rect x='13.5' y='5' width='4' height='14' rx='1.5'/></svg>"); }
.fm-nowbar[data-paused] .fm-nowbar-play { background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='context-fill'><path d='M8 5.5v13a1 1 0 0 0 1.5.9l10.2-6.5a1 1 0 0 0 0-1.7L9.5 4.6A1 1 0 0 0 8 5.5z'/></svg>"); }
.fm-nowbar-mute { background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='context-fill' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z' fill='context-fill'/><path d='M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11'/></svg>"); }
.fm-nowbar[data-muted] .fm-nowbar-mute { background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='context-fill' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z' fill='context-fill'/><path d='M16 9.5l5 5M21 9.5l-5 5'/></svg>"); }
.fm-nowbar-close { background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='context-fill' stroke-width='2' stroke-linecap='round'><path d='M7 7l10 10M17 7L7 17'/></svg>"); background-size: 14px; opacity: .7; }
:root[fm-nowbar] .fm-toasts { bottom: 76px; }
.fm-nowbar { cursor: grab; }
.fm-nowbar.fm-dragging { cursor: grabbing; transition: opacity .25s ease !important; }
.fm-nowbar[data-moved] { translate: 0 18px; }
.fm-nowbar[data-moved].fm-in { translate: 0 0; }
.fm-nowbar-btn[hidden] { display: none !important; }
/* обложка трека в кружке слева */
.fm-nowbar-eq { position: relative; overflow: hidden; }
.fm-nowbar-art { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; display: none; }
.fm-nowbar[data-art] .fm-nowbar-art { display: block; }
.fm-nowbar[data-art] .fm-nowbar-eq { box-shadow: 0 0 0 1px var(--fm-line); }
.fm-nowbar[data-art][data-paused] .fm-nowbar-art { opacity: .55; filter: grayscale(.4); }
/* полоска прогресса */
.fm-nowbar-progress {
  position: absolute; left: 46px; right: 16px; bottom: 3px; height: 2px;
  border-radius: 2px; background: var(--fm-line); overflow: hidden; display: none;
}
.fm-nowbar[data-progress] .fm-nowbar-progress { display: block; }
.fm-nowbar-progress-fill {
  height: 100%; background: var(--fm-accent); transform-origin: 0 50%; transform: scaleX(0);
  transition: transform 1s linear;
}
/* мини-режим: только кружок с обложкой, при наведении раскрывается */
.fm-nowbar.fm-mini { padding: 5px; gap: 0; }
.fm-nowbar.fm-mini > :not(.fm-nowbar-eq) { display: none !important; }
.fm-nowbar.fm-mini .fm-nowbar-eq { width: 34px; height: 34px; }
.fm-nowbar.fm-in:not(.fm-mini) { animation: fm-nowbar-grow .35s cubic-bezier(.2, .9, .25, 1.15); }
@keyframes fm-nowbar-grow { from { scale: .92; } }
.fm-nowbar-prev { background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='context-fill'><rect x='5' y='6' width='2.4' height='12' rx='1.2'/><path d='M18.5 6.6v10.8a1 1 0 0 1-1.55.83L9.3 13.07a1.3 1.3 0 0 1 0-2.14l7.65-5.16a1 1 0 0 1 1.55.83z'/></svg>"); }
.fm-nowbar-next { background-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='context-fill'><rect x='16.6' y='6' width='2.4' height='12' rx='1.2'/><path d='M5.5 6.6v10.8a1 1 0 0 0 1.55.83l7.65-5.16a1.3 1.3 0 0 0 0-2.14L7.05 5.77A1 1 0 0 0 5.5 6.6z'/></svg>"); }


/* ======== НОВЫЕ ФУНКЦИИ (скрипт floorp-modern.uc.js) ======== */

/* полоска загрузки страницы */
#navigator-toolbox { position: relative !important; }
.fm-progress {
  position: absolute; inset-inline: 0; bottom: 0; height: 2px;
  pointer-events: none; opacity: 0; transition: opacity .25s ease; z-index: 10;
}
.fm-progress.fm-active { opacity: 1; }
.fm-progress-fill {
  height: 100%; transform-origin: 0 50%; transform: scaleX(0);
  background: linear-gradient(90deg, var(--fm-accent), color-mix(in srgb, var(--fm-accent) 55%, #22d3ee));
  box-shadow: 0 0 10px var(--fm-accent);
  border-radius: 0 2px 2px 0;
  transition: transform .35s cubic-bezier(.2, .8, .2, 1);
}

/* всплывающие уведомления */
.fm-toasts {
  position: absolute; inset-inline: 0; bottom: 28px; z-index: 1000;
  display: flex; flex-direction: column; align-items: center; gap: 8px;
  pointer-events: none;
}
.fm-toast {
  display: flex; align-items: center; gap: 10px;
  padding: 11px 18px 11px 14px; border-radius: 999px;
  background: var(--fm-bar); color: var(--fm-ink);
  font: 500 13.5px var(--fm-font);
  box-shadow: var(--fm-shine), var(--fm-pop);
  border: 1px solid var(--fm-line);
  opacity: 0; transform: translateY(14px) scale(.96);
  transition: opacity .28s ease, transform .35s cubic-bezier(.2, .9, .25, 1.2);
}
.fm-toast.fm-in { opacity: 1; transform: none; }
.fm-toast.fm-out { opacity: 0; transform: translateY(8px) scale(.98); }
.fm-toast-dot {
  width: 9px; height: 9px; border-radius: 50%; background: var(--fm-accent);
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--fm-accent) 22%, transparent);
}
.fm-toast[data-kind="ok"] .fm-toast-dot { background: #34c759; box-shadow: 0 0 0 4px rgb(52 199 89 / .22); }
.fm-toast[data-kind="warn"] .fm-toast-dot { background: #ff9f0a; box-shadow: 0 0 0 4px rgb(255 159 10 / .22); }

/* кнопка темы */
#fm-theme-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='context-fill' stroke-width='2.1' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='8'/><path d='M12 4a8 8 0 0 1 0 16z' fill='context-fill'/></svg>") !important; }
#fm-theme-button[fm-theme="1"] { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='context-fill' stroke-width='2.1' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='4'/><path d='M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4'/></svg>") !important; }
#fm-theme-button[fm-theme="0"] { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='context-fill' stroke-width='2.1' stroke-linecap='round' stroke-linejoin='round'><path d='M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z'/></svg>") !important; }

/* плавное появление страницы при переключении вкладок */

/* ======== ПЛАВНОСТЬ: анимации интерфейса ========
   Только прозрачность, сдвиг и масштаб — видеокарта рисует их без нагрузки.
   --fm-spring  пружина (с лёгким перелётом), --fm-ease  мягкое торможение,
   --fm-k       множитель длительности. Режим «Как в iOS» в установщике
   подменяет их на настоящие пружины (linear()). */
:root {
  --fm-spring: cubic-bezier(.2, .9, .25, 1.15);
  --fm-ease: cubic-bezier(.2, .8, .2, 1);
  --fm-k: 1;
}

/* ---- вкладки ---- */
/* новая вкладка «выныривает» */
.tabbrowser-tab:not([pinned]) > .tab-stack { animation: fm-tab-open calc(.42s * var(--fm-k)) var(--fm-spring) both; }
@keyframes fm-tab-open { from { opacity: 0; translate: 0 10px; scale: .86; } }
/* закрываемая вкладка сжимается и тает, пока Firefox убирает её место */
.tabbrowser-tab > .tab-stack { transition: opacity calc(.2s * var(--fm-k)) ease, scale calc(.25s * var(--fm-k)) var(--fm-ease); }
.tabbrowser-tab[closing] > .tab-stack { opacity: 0; scale: .85; }
/* выбранная вкладка мягко «вспухает» */
.tabbrowser-tab[selected] .tab-background { animation: fm-tab-sel calc(.45s * var(--fm-k)) var(--fm-spring); }
@keyframes fm-tab-sel { from { scale: .9; opacity: .4; } }
.tabbrowser-tab .tab-background {
  transition: background-color calc(.28s * var(--fm-k)) ease, box-shadow calc(.3s * var(--fm-k)) ease,
              outline-color calc(.28s * var(--fm-k)) ease, scale calc(.35s * var(--fm-k)) var(--fm-spring) !important;
}
.tabbrowser-tab:not([selected]):active .tab-background { scale: .95; }
.tabbrowser-tab .tab-close-button {
  transition: opacity .2s ease, background-color .2s ease, scale calc(.3s * var(--fm-k)) var(--fm-spring) !important;
}
.tabbrowser-tab .tab-close-button:hover { scale: 1.15; }
.tabbrowser-tab .tab-close-button:active { scale: .85; }
.tabbrowser-tab .tab-label { transition: color .25s ease !important; }
.tabbrowser-tab .tab-icon-image { transition: scale calc(.35s * var(--fm-k)) var(--fm-spring) !important; }

/* вертикальные вкладки: при раскрытии панели названия выплывают следом */
:root:has(#sidebar-main[expanded]) #tabbrowser-tabs[orient="vertical"] :is(.tab-label-container, .tab-close-button),
#sidebar-main[expanded] :is(.tools-and-extensions moz-button, moz-button)::part(button) {
  animation: fm-label calc(.4s * var(--fm-k)) var(--fm-ease) both;
}
@keyframes fm-label { from { opacity: 0; translate: -10px 0; } }
#sidebar-main moz-button::part(button), .tools-and-extensions moz-button::part(button) {
  transition: background-color .2s ease, scale calc(.3s * var(--fm-k)) var(--fm-spring) !important;
}
#sidebar-main moz-button:active::part(button) { scale: .9; }

/* ---- кнопки панели ---- */
toolbar .toolbarbutton-1 > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack) {
  transition: background-color .22s ease, scale calc(.38s * var(--fm-k)) var(--fm-spring),
              translate calc(.38s * var(--fm-k)) var(--fm-spring), rotate calc(.55s * var(--fm-k)) var(--fm-spring) !important;
}
toolbar .toolbarbutton-1:not([disabled]):hover > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack) { scale: 1.08; }
toolbar .toolbarbutton-1:not([disabled]):active > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack) { scale: .84; }
#back-button:not([disabled]):active > .toolbarbutton-icon { translate: -4px 0; scale: .9; }
#forward-button:not([disabled]):active > .toolbarbutton-icon { translate: 4px 0; scale: .9; }
#reload-button:not([disabled]):active > .toolbarbutton-icon { rotate: 150deg; scale: .9; }
toolbarbutton:is([open], [checked]) > :is(.toolbarbutton-icon, .toolbarbutton-badge-stack) {
  animation: fm-press calc(.45s * var(--fm-k)) var(--fm-spring);
}
@keyframes fm-press { from { scale: .8; } }

/* ---- меню и панели: раскрываются из точки, откуда их вызвали ---- */
menupopup::part(content) {
  animation: fm-pop calc(.32s * var(--fm-k)) var(--fm-spring) both;
  transform-origin: 50% 0;
}
@keyframes fm-pop { from { opacity: 0; translate: 0 -6px; scale: .9; } }
panel[type="arrow"]::part(content) {
  animation: fm-panel calc(.42s * var(--fm-k)) var(--fm-spring) both;
  transform-origin: 85% 0;
}
@keyframes fm-panel { from { opacity: 0; translate: 0 -10px; scale: .88; } }
/* плитки главного меню ☰ появляются волной */
#appMenu-mainView .subviewbutton { animation: fm-tile calc(.4s * var(--fm-k)) var(--fm-spring) both; }
#appMenu-mainView .subviewbutton:nth-child(2) { animation-delay: .02s; }
#appMenu-mainView .subviewbutton:nth-child(3) { animation-delay: .04s; }
#appMenu-mainView .subviewbutton:nth-child(4) { animation-delay: .06s; }
#appMenu-mainView .subviewbutton:nth-child(5) { animation-delay: .08s; }
#appMenu-mainView .subviewbutton:nth-child(6) { animation-delay: .10s; }
#appMenu-mainView .subviewbutton:nth-child(7) { animation-delay: .12s; }
#appMenu-mainView .subviewbutton:nth-child(8) { animation-delay: .14s; }
#appMenu-mainView .subviewbutton:nth-child(n+9) { animation-delay: .16s; }
@keyframes fm-tile { from { opacity: 0; translate: 0 8px; scale: .94; } }
.subviewbutton, menupopup :is(menuitem, menu) {
  transition: background-color .16s ease, color .16s ease, scale calc(.3s * var(--fm-k)) var(--fm-spring) !important;
}
.subviewbutton:not([disabled]):active, menupopup :is(menuitem, menu):not([disabled]):active { scale: .97; }

/* ---- адресная строка ---- */
#urlbar > :is(#urlbar-background, .urlbar-background), .urlbar > .urlbar-background {
  transition: outline-color .3s ease, box-shadow .4s ease, background-color .3s ease,
              scale calc(.45s * var(--fm-k)) var(--fm-spring) !important;
}
#urlbar:is([focused], [open]) > :is(#urlbar-background, .urlbar-background) { scale: 1.006; }
#urlbar[open] .urlbarView { animation: fm-drop calc(.38s * var(--fm-k)) var(--fm-spring) both; transform-origin: 50% 0; }
.urlbarView-row { animation: fm-row calc(.32s * var(--fm-k)) var(--fm-ease) both; }
.urlbarView-row:nth-child(2) { animation-delay: .025s; }
.urlbarView-row:nth-child(3) { animation-delay: .05s; }
.urlbarView-row:nth-child(4) { animation-delay: .075s; }
.urlbarView-row:nth-child(5) { animation-delay: .1s; }
.urlbarView-row:nth-child(6) { animation-delay: .125s; }
.urlbarView-row:nth-child(n+7) { animation-delay: .15s; }
@keyframes fm-row { from { opacity: 0; translate: 0 -6px; } }

/* ---- страница: плавная смена при переключении вкладок ---- */
#tabbrowser-tabpanels > .deck-selected .browserStack {
  animation: fm-tab-in calc(.3s * var(--fm-k)) var(--fm-ease);
}
@keyframes fm-tab-in { from { opacity: .5; scale: .992; } }

/* ---- плашки, поиск, боковые панели ---- */
notification-message { animation: fm-drop calc(.45s * var(--fm-k)) var(--fm-spring) both; }
@keyframes fm-drop { from { opacity: 0; translate: 0 -12px; scale: .97; } }
findbar:not([hidden]) { animation: fm-rise calc(.38s * var(--fm-k)) var(--fm-spring) both; }
@keyframes fm-rise { from { opacity: 0; translate: 0 12px; } }
#sidebar-box:not([hidden]) { animation: fm-side calc(.42s * var(--fm-k)) var(--fm-spring) both; }
@keyframes fm-side { from { opacity: 0; translate: -18px 0; scale: .98; } }
/* боковая панель сайтов Floorp: значки пружинят, сама панель выезжает */
.panel-sidebar-panel, .panel-sidebar-actions {
  transition: background-color .2s ease, scale calc(.35s * var(--fm-k)) var(--fm-spring) !important;
}
.panel-sidebar-panel:hover, .panel-sidebar-actions:hover { scale: 1.1; }
.panel-sidebar-panel:active, .panel-sidebar-actions:active { scale: .88; }
.panel-sidebar-panel[data-checked="true"] { animation: fm-press calc(.45s * var(--fm-k)) var(--fm-spring); }
#panel-sidebar-box:not([hidden], [collapsed]) { animation: fm-side calc(.42s * var(--fm-k)) var(--fm-spring) both; }

/* закладки на панели появляются друг за другом при открытии окна */
#PlacesToolbarItems > .bookmark-item { animation: fm-row calc(.34s * var(--fm-k)) var(--fm-ease) both; }
#PlacesToolbarItems > .bookmark-item { transition: background-color .2s ease, scale calc(.35s * var(--fm-k)) var(--fm-spring) !important; }

@media (prefers-reduced-motion: reduce) {
  .tabbrowser-tab > .tab-stack, .tabbrowser-tab .tab-background, panel[type="arrow"]::part(content), menupopup::part(content),
  #appMenu-mainView .subviewbutton, .urlbarView, .urlbarView-row, notification-message, findbar, #sidebar-box,
  #panel-sidebar-box, .panel-sidebar-panel, toolbarbutton > .toolbarbutton-icon, toolbarbutton > .toolbarbutton-badge-stack,
  #PlacesToolbarItems > .bookmark-item, #tabbrowser-tabpanels .browserStack,
  #tabbrowser-tabs .tab-label-container, #tabbrowser-tabs .tab-close-button { animation: none !important; }
}

/* кнопка Floorp Modern Studio */
#fm-studio-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='context-fill' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M12 3a9 9 0 1 0 0 18c1.1 0 1.7-.9 1.4-1.9-.3-1 .3-2.1 1.4-2.1H17a4 4 0 0 0 4-4c0-5.5-4-10-9-10z'/><circle cx='7.5' cy='11' r='1.2' fill='context-fill'/><circle cx='10' cy='7' r='1.2' fill='context-fill'/><circle cx='15' cy='7.5' r='1.2' fill='context-fill'/></svg>") !important; }
#appMenu-fm-studio { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M12 3a9 9 0 1 0 0 18c1.1 0 1.7-.9 1.4-1.9-.3-1 .3-2.1 1.4-2.1H17a4 4 0 0 0 4-4c0-5.5-4-10-9-10z'/><circle cx='7.5' cy='11' r='1.2' fill='white'/><circle cx='10' cy='7' r='1.2' fill='white'/><circle cx='15' cy='7.5' r='1.2' fill='white'/></svg>") !important; --fm-tile: #8e6bff; }

/* ======== ПАНЕЛИ ======== */
/* загрузки */
#downloadsPanel { --panel-padding: 8px !important; }
#downloadsListBox > richlistitem {
  border-radius: 16px !important; margin: 2px 0 !important; padding-block: 6px !important;
}
#downloadsListBox > richlistitem:hover { background: var(--fm-hover) !important; }
#downloadsListBox > richlistitem[selected] { background: var(--fm-soft) !important; }
.downloadProgress::-moz-progress-bar { background: var(--fm-accent) !important; border-radius: 999px !important; }
.downloadProgress { border-radius: 999px !important; background: var(--fm-hover) !important; }
.downloadButton { border-radius: 999px !important; }
/* расширения */
.unified-extensions-item, .unified-extensions-item-action-button, .unified-extensions-item-menu-button {
  border-radius: 16px !important;
}
.unified-extensions-item-icon, .unified-extensions-item .webextension-browser-action > .toolbarbutton-badge-stack {
  border-radius: 10px !important;
}
/* главное меню */
#appMenu-popup .panel-header, .panel-header { padding-block: 10px !important; }
.panel-header > h1 { font-weight: 600 !important; font-size: 15px !important; }
.panel-subview-body { padding-inline: 4px !important; }
toolbarseparator, .panel-subview-body > toolbarseparator { opacity: .45 !important; }
.toolbaritem-combined-buttons > .subviewbutton { border-radius: 999px !important; }
#appMenu-zoom-controls .subviewbutton { border-radius: 999px !important; }
/* разрешения сайтов, защита */
#identity-popup, #permission-popup, #protections-popup { --panel-border-radius: 26px !important; }
.protections-popup-section, .identity-popup-section { border-radius: 18px !important; }
moz-toggle { --toggle-background-color-pressed: var(--fm-accent) !important; --color-accent-primary: var(--fm-accent) !important; }



/* ======== ЦВЕТА ЧЕРЕЗ ПЕРЕМЕННЫЕ FIREFOX 156 (доходят и внутрь встроенных компонентов) ======== */
:root, menupopup, panel, tooltip, #urlbar, .urlbarView {
  --fm-menu: light-dark(#ffffff, #1c1d20);
  /* меню и всплывающие панели */
  --panel-background-color: var(--fm-menu) !important;
  --panel-text-color: var(--fm-ink) !important;
  --panel-border-color: var(--fm-line) !important;
  --panel-border-radius: 24px !important;
  --panel-separator-color: var(--fm-line) !important;
  --panel-item-hover-bgcolor: color-mix(in srgb, var(--fm-ink) 8%, transparent) !important;
  --panel-item-active-bgcolor: color-mix(in srgb, var(--fm-ink) 13%, transparent) !important;
  --menuitem-hover-background-color: color-mix(in srgb, var(--fm-ink) 8%, transparent) !important;
  --menu-background-color: var(--fm-menu) !important;
  --menu-color: var(--fm-ink) !important;
  --menu-border-color: var(--fm-line) !important;
  --arrowpanel-background: var(--fm-menu) !important;
  --arrowpanel-color: var(--fm-ink) !important;
  --arrowpanel-border-color: var(--fm-line) !important;
  --background-color-box: var(--fm-menu) !important;
  /* адресная строка и её выпадающий список */
  --toolbar-field-background-color: color-mix(in srgb, currentColor 9%, var(--fm-frame)) !important;
  --toolbar-field-background-color-focus: var(--fm-menu) !important;
  --toolbar-field-focus-background-color: var(--fm-menu) !important;
  --toolbar-field-border-color: transparent !important;
  --toolbar-field-border-color-focus: var(--fm-accent) !important;
  --urlbar-background-color: color-mix(in srgb, currentColor 9%, var(--fm-frame)) !important;
  --urlbar-background-color-focus: var(--fm-menu) !important;
  --urlbar-border-radius: 22px !important;
  --urlbar-box-background-color-hover: color-mix(in srgb, var(--fm-ink) 9%, transparent) !important;
  --urlbar-box-background-color-active: color-mix(in srgb, var(--fm-ink) 14%, transparent) !important;
  --urlbarview-border-radius: 16px !important;
  --urlbarview-row-min-height: 44px !important;
  --urlbarview-background-color-hover: color-mix(in srgb, var(--fm-ink) 7%, transparent) !important;
  --urlbarview-background-color-selected: var(--fm-soft) !important;
  --urlbarview-text-color-selected: var(--fm-ink) !important;
  --urlbarview-text-color-secondary: var(--fm-muted) !important;
  --urlbarview-text-color-action: var(--fm-accent) !important;
  --urlbarview-separator-color: var(--fm-line) !important;
  --urlbarview-action-button-background-color-hover: color-mix(in srgb, var(--fm-ink) 10%, transparent) !important;
}
tooltip { --panel-background-color: var(--fm-menu) !important; }

/* ======== МЕНЮ И ПАНЕЛИ В СТИЛЕ GALAXY ======== */
:root { --fm-menu: light-dark(#ffffff, #1c1d20); }
/* рисуем фон меню сами: у Nova свой серо-фиолетовый */
menupopup::part(content), panel::part(content) {
  background-color: var(--fm-menu) !important;
  color: var(--fm-ink) !important;
  border: 1px solid var(--fm-line) !important;
  border-radius: 24px !important;
  box-shadow: var(--fm-pop) !important;
}
menupopup, panel {
  --panel-background: var(--fm-menu) !important;
  --arrowpanel-background: var(--fm-menu) !important;
  --panel-item-hover-bgcolor: color-mix(in srgb, var(--fm-ink) 8%, transparent) !important;
}
menupopup > :is(menuitem, menu) { padding-block: 7px !important; margin-inline: 4px !important; }
menupopup > :is(menuitem, menu):is([_moz-menuactive], :hover):not([disabled]) {
  background-color: color-mix(in srgb, var(--fm-ink) 8%, transparent) !important;
  color: var(--fm-ink) !important;
}
menupopup > :is(menuitem, menu)[_moz-menuactive] > .menu-icon { scale: 1.06; }
.menu-accel, .menu-text + .menu-accel-container, .subviewbutton > .toolbarbutton-text + .toolbarbutton-accel {
  color: var(--fm-muted) !important; opacity: 1 !important;
}

/* главное меню: цветные круглые иконки у пунктов, как в настройках Galaxy */
#appMenu-new-tab-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M12 5v14M5 12h14'/></svg>") !important; --fm-tile: #3e91ff; }
#appMenu-new-window-button2, #appMenu-new-classic-window-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><rect x='3.5' y='5' width='17' height='14' rx='3'/><path d='M3.5 9.5h17'/></svg>") !important; --fm-tile: #19b5a5; }
#appMenu-new-private-window-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M3 11c2-1 5.5-1.5 9-1.5s7 .5 9 1.5'/><circle cx='8' cy='14.5' r='2.5'/><circle cx='16' cy='14.5' r='2.5'/></svg>") !important; --fm-tile: #8e6bff; }
#appMenu-history-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='8'/><path d='M12 7.5V12l3 2'/></svg>") !important; --fm-tile: #ff8a3d; }
#appMenu-bookmarks-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M7 3.5h10v17l-5-4-5 4z'/></svg>") !important; --fm-tile: #f5a300; }
#appMenu-downloads-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M12 4v10.5'/><path d='M7.5 10.5L12 15l4.5-4.5'/><path d='M5 19.5h14'/></svg>") !important; --fm-tile: #2fb85a; }
#appMenu-passwords-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><circle cx='8' cy='12' r='3.5'/><path d='M11.5 12H20v3M17 12v2.5'/></svg>") !important; --fm-tile: #6b7a99; }
#appMenu-extensions-themes-button, #appMenu-unified-extensions-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M9.5 4.5a2 2 0 0 1 4 0V6H17a1 1 0 0 1 1 1v3.5h1.5a2 2 0 0 1 0 4H18V18a1 1 0 0 1-1 1h-3.5v-1.5a2 2 0 0 0-4 0V19H6a1 1 0 0 1-1-1v-3.5h1.5a2 2 0 0 0 0-4H5V7a1 1 0 0 1 1-1h3.5z'/></svg>") !important; --fm-tile: #a35cff; }
#appMenu-print-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M7 9V3.5h10V9'/><rect x='3.5' y='9' width='17' height='8' rx='2.5'/><path d='M7 14h10v6.5H7z'/></svg>") !important; --fm-tile: #7a7f87; }
#appMenu-save-file-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M5 4h11l3 3v13H5z'/><path d='M8 4v5h7V4M8 20v-6h8v6'/></svg>") !important; --fm-tile: #3e91ff; }
#appMenu-translate-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6h9M8.5 4v2M6 6c.5 3 2.5 5.5 5 7M11 6c-.5 3-3 6-6 8'/><path d='M13 20l3.5-8 3.5 8M14 17.5h5'/></svg>") !important; --fm-tile: #00a8e8; }
#appMenu-find-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><circle cx='11' cy='11' r='6'/><path d='M20 20l-4.2-4.2'/></svg>") !important; --fm-tile: #5b8cff; }
#appMenu-settings-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='3'/><path d='M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8'/></svg>") !important; --fm-tile: #8a8f98; }
#appMenu-more-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><circle cx='6' cy='12' r='1.3' fill='white'/><circle cx='12' cy='12' r='1.3' fill='white'/><circle cx='18' cy='12' r='1.3' fill='white'/></svg>") !important; --fm-tile: #5e6470; }
#appMenu-help-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='8.5'/><path d='M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .8-1 1.5v.4'/><circle cx='12' cy='17' r='.6' fill='white'/></svg>") !important; --fm-tile: #34aadc; }
#appMenu-profiles-button, #appMenu-create-profile-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='8.5' r='3.5'/><path d='M5 19.5c1.3-3.3 4-5 7-5s5.7 1.7 7 5'/></svg>") !important; --fm-tile: #ff5c8a; }
#appMenu-tab-groups-button { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><rect x='3.5' y='4' width='7' height='7' rx='2'/><rect x='13.5' y='4' width='7' height='7' rx='2'/><rect x='3.5' y='14' width='7' height='7' rx='2'/></svg>") !important; --fm-tile: #19b5a5; }
#appMenu-quit-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M12 3.5v8'/><path d='M7 6.5a7.5 7.5 0 1 0 10 0'/></svg>") !important; --fm-tile: #ff453a; }
#appMenu-fullscreen-button2 { list-style-image: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><path d='M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5'/></svg>") !important; --fm-tile: #5e6470; }
#appMenu-mainView .subviewbutton:is(#appMenu-new-tab-button2, #appMenu-new-window-button2, #appMenu-new-classic-window-button, #appMenu-new-private-window-button2, #appMenu-history-button, #appMenu-bookmarks-button, #appMenu-downloads-button, #appMenu-passwords-button, #appMenu-extensions-themes-button, #appMenu-unified-extensions-button, #appMenu-print-button2, #appMenu-save-file-button2, #appMenu-translate-button, #appMenu-find-button2, #appMenu-settings-button, #appMenu-more-button2, #appMenu-help-button2, #appMenu-profiles-button, #appMenu-create-profile-button, #appMenu-tab-groups-button, #appMenu-quit-button2, #appMenu-fullscreen-button2, #appMenu-fm-studio) > .toolbarbutton-icon {
  display: flex !important;
  width: 30px !important; height: 30px !important;
  padding: 7px !important; box-sizing: border-box !important;
  margin-inline-end: 12px !important;
  border-radius: 50% !important;
  background: var(--fm-tile) !important;
  box-shadow: inset 0 -2px 3px rgb(0 0 0 / .15), 0 2px 6px color-mix(in srgb, var(--fm-tile) 40%, transparent) !important;
}
#appMenu-mainView .subviewbutton { min-height: 44px !important; padding-inline: 10px !important; border-radius: 16px !important; }
#appMenu-mainView .subviewbutton > .toolbarbutton-text { font-size: 14px !important; font-weight: 500 !important; }
#appMenu-mainView .subviewbutton:not([disabled]):hover { background: color-mix(in srgb, var(--fm-ink) 7%, transparent) !important; }
#appMenu-popup toolbarseparator { margin-inline: 14px !important; }

/* выпадающий список адресной строки */
#urlbar[open] > :is(#urlbar-background, .urlbar-background) {
  background: var(--fm-menu) !important;
  border-radius: 26px !important;
  border: 1px solid var(--fm-line) !important;
}
.urlbarView { margin-inline: 4px !important; }
.urlbarView-body-outer, .urlbarView-body-inner { border: 0 !important; }
.urlbarView-row { background: transparent !important; padding-block: 1px !important; }
.urlbarView-row-inner { min-height: 44px !important; padding-block: 6px !important; padding-inline: 8px !important; }
.urlbarView-row:not([selected]):hover > .urlbarView-row-inner { background: color-mix(in srgb, var(--fm-ink) 7%, transparent) !important; }
.urlbarView-row[selected] > .urlbarView-row-inner { background: var(--fm-soft) !important; }
.urlbarView-favicon {
  width: 32px !important; height: 32px !important; padding: 8px !important; box-sizing: border-box !important;
  margin-inline-end: 12px !important; border-radius: 50% !important;
  background: color-mix(in srgb, var(--fm-ink) 9%, transparent) !important;
}
.urlbarView-row[selected] .urlbarView-favicon { background: var(--fm-accent) !important; fill: var(--fm-on-accent) !important; }
.urlbarView-title { font-size: 14px !important; font-weight: 500 !important; }
.urlbarView-row[selected] .urlbarView-title { color: var(--fm-ink) !important; }
.urlbarView-action, .urlbarView-url, .urlbarView-title-separator::before { color: var(--fm-muted) !important; }
.urlbarView-row[selected] :is(.urlbarView-action, .urlbarView-url) { color: var(--fm-accent) !important; }
.urlbarView-button { border-radius: 999px !important; }
.search-one-offs, #urlbar .search-panel-one-offs-header { border-top: 0 !important; }
.searchbar-engine-one-off-item { border-radius: 999px !important; }

/* адресная строка: мягкая обводка цветом акцента ВСЕГДА (не только в фокусе).
   Цвет приглушён: берём акцент и смешиваем с фоном, чтобы даже яркий
   акцент Windows не резал глаз. В фокусе обводка чуть плотнее. */
:root {
  --fm-ring: color-mix(in srgb, var(--fm-accent) 42%, transparent);
  --fm-ring-focus: color-mix(in srgb, var(--fm-accent) 62%, transparent);
  --fm-ring-glow: color-mix(in srgb, var(--fm-accent) 12%, transparent);
  --urlbar-background-outline-focused: none !important;
  --urlbar-input-container-outline-open-focused: none !important;
}
#urlbar > :is(#urlbar-background, .urlbar-background),
.urlbar > .urlbar-background {
  outline: 1.5px solid var(--fm-ring) !important;
  outline-offset: -1.5px !important;
  border-color: transparent !important;
  box-shadow: 0 0 14px var(--fm-ring-glow) !important;
  animation: none !important;
}
#urlbar:is([focused], [open], [popover-open], [breakout-extend], :focus-within) > :is(#urlbar-background, .urlbar-background),
.urlbar:is([focused], [open], [popover-open], :focus-within) > .urlbar-background {
  outline: 2px solid var(--fm-ring-focus) !important;
  outline-offset: -2px !important;
  box-shadow: 0 0 18px color-mix(in srgb, var(--fm-accent) 16%, transparent) !important;
}
.urlbar > .urlbar-input-container { outline: none !important; }

/* активная вкладка мягко светится цветом акцента */
.tabbrowser-tab[selected] > .tab-stack > .tab-background {
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--fm-accent) 35%, transparent),
              0 4px 16px color-mix(in srgb, var(--fm-accent) 22%, transparent) !important;
}

/* кнопки в фокусе меню: акцентная подсветка вместо серой */
menupopup > :is(menuitem, menu):is([_moz-menuactive]):not([disabled]) {
  background-color: color-mix(in srgb, var(--fm-accent) 16%, transparent) !important;
}



/* ======== ОКНО «БИБЛИОТЕКА» (журнал, загрузки, закладки) ======== */
@-moz-document url("chrome://browser/content/places/places.xhtml") {
  :root, #placesView, #placesToolbox, #placesToolbar, #placesViewsBox, #contentView,
  #placesList, #placeContent, #downloadsListBox, #detailsPane, #infoBox {
    background-color: var(--fm-frame) !important;
    background-image: none !important;
    color: var(--fm-ink) !important;
    border: 0 !important;
    box-shadow: none !important;
    appearance: none !important;
  }
  :root { font-family: var(--fm-font) !important; }
  #placesToolbox { padding: 8px 10px !important; }
  #placesToolbar { gap: 4px !important; align-items: center !important; }
  :is(#back-button, #forward-button) { border-radius: 999px !important; }
  :is(#placesToolbar > toolbarbutton, #placesMenu > menu, #clearDownloadsButton) {
    border-radius: 999px !important;
    padding: 6px 14px !important;
    margin: 0 2px !important;
    background: transparent !important;
    border: 0 !important;
  }
  :is(#placesToolbar > toolbarbutton, #placesMenu > menu, #clearDownloadsButton):hover,
  #placesMenu > menu[open] {
    background: color-mix(in srgb, var(--fm-ink) 9%, transparent) !important;
  }
  #searchFilter {
    border-radius: 999px !important;
    border: 0 !important;
    outline: none !important;
    min-height: 36px !important;
    padding-inline: 14px !important;
    background-color: color-mix(in srgb, var(--fm-ink) 9%, transparent) !important;
    color: var(--fm-ink) !important;
  }
  #searchFilter:focus-within { outline: 2px solid var(--fm-ring-focus, var(--fm-accent)) !important; outline-offset: -2px !important; }
  /* разделители между панелями — убрать */
  #placesView > splitter, splitter {
    border: 0 !important;
    background: transparent !important;
    min-width: 6px !important;
    width: 6px !important;
  }
  /* левая колонка: пункты-«таблетки» */
  #placesList { margin: 8px 4px 8px 8px !important; }
  #placesList treechildren::-moz-tree-row { min-height: 40px !important; }
  /* загрузки: скруглённые карточки, выделение мягкой заливкой без рамки */
  #downloadsListBox { margin: 8px 10px !important; padding: 0 !important; }
  #downloadsListBox > richlistitem {
    border: 0 !important;
    outline: none !important;
    border-radius: 18px !important;
    margin-block: 3px !important;
    padding: 10px 12px !important;
    background: transparent !important;
  }
  #downloadsListBox > richlistitem:hover { background: color-mix(in srgb, var(--fm-ink) 6%, transparent) !important; }
  #downloadsListBox > richlistitem[selected],
  #downloadsListBox:focus > richlistitem[selected],
  #downloadsListBox > richlistitem[selected][current] {
    background: color-mix(in srgb, var(--fm-accent) 14%, transparent) !important;
    border: 0 !important;
    outline: none !important;
    box-shadow: none !important;
  }
  #downloadsListBox .downloadTarget { font-weight: 600 !important; font-size: 14px !important; }
  #downloadsListBox .downloadDetails { color: var(--fm-muted) !important; opacity: 1 !important; }
  #downloadsListBox .downloadButton { border-radius: 999px !important; }
  #downloadsListBox .downloadButton:hover { background: color-mix(in srgb, var(--fm-ink) 10%, transparent) !important; }
  .downloadProgress { border-radius: 999px !important; }
  .downloadProgress::-moz-progress-bar { background: var(--fm-accent) !important; border-radius: 999px !important; }
  /* таблица закладок/журнала справа */
  #placeContent { margin: 8px 10px !important; }
  #placeContent treecol, #placeContent treecolpicker {
    background: transparent !important; border: 0 !important; color: var(--fm-muted) !important;
  }
  #placeContent treechildren::-moz-tree-row(odd) { background-color: transparent !important; }
  #detailsPane, #infoBox { border-top: 0 !important; padding: 10px 14px !important; }
}

/* ======== ПАНЕЛИ ЗАКЛАДОК И ЖУРНАЛА (старое «дерево» Firefox) ======== */
@-moz-document url-prefix("chrome://browser/content/places/"), url-prefix("chrome://browser/content/sidebar/"), url-prefix("chrome://browser/content/bookmarks/"), url-prefix("chrome://browser/content/history/") {
  :root, body, #bookmarksPanel, #history-panel, page, window {
    background-color: var(--fm-frame, light-dark(#f2f3f5, #000)) !important;
    color: var(--fm-ink, light-dark(#111214, #f2f2f3)) !important;
    font-family: "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif !important;
  }
  #sidebar-search-container, .sidebar-search-container {
    padding: 10px 12px 8px !important;
    background: transparent !important;
  }
  :is(search-textbox, moz-input-search, input[type="search"], #search-box) {
    border-radius: 999px !important;
    border: 0 !important;
    background-color: color-mix(in srgb, currentColor 9%, transparent) !important;
    min-height: 36px !important;
    padding-inline: 12px !important;
    outline: none !important;
  }
  :is(search-textbox, moz-input-search, input[type="search"], #search-box):focus-within {
    outline: 2px solid var(--fm-accent, AccentColor) !important;
    outline-offset: -2px !important;
  }
  tree, #bookmarks-view, #historyTree {
    background-color: transparent !important;
    border: 0 !important;
    color: inherit !important;
    margin: 0 6px !important;
    appearance: none !important;
  }
  tree:focus-visible { outline: none !important; }
  treechildren::-moz-tree-row {
    min-height: 36px !important;
    background-color: transparent !important;
    border: 0 !important;
  }
  treechildren::-moz-tree-row(hover) {
    background-color: color-mix(in srgb, currentColor 7%, transparent) !important;
  }
  treechildren::-moz-tree-row(selected),
  treechildren::-moz-tree-row(selected, focus),
  treechildren::-moz-tree-row(selected, current, focus) {
    background-color: color-mix(in srgb, var(--fm-accent, AccentColor) 16%, transparent) !important;
    border: 0 !important;
    outline: none !important;
  }
  treechildren::-moz-tree-row(current, focus) { outline: none !important; border: 0 !important; }
  treechildren::-moz-tree-cell-text {
    color: inherit !important;
    padding-inline-start: 6px !important;
    font-size: 13.5px !important;
  }
  treechildren::-moz-tree-cell-text(selected),
  treechildren::-moz-tree-cell-text(selected, focus) {
    color: var(--fm-ink, light-dark(#111214, #f2f2f3)) !important;
    font-weight: 600 !important;
  }
  treechildren::-moz-tree-twisty { padding-inline: 6px !important; opacity: .7; }
  treechildren::-moz-tree-image { margin-inline-end: 4px !important; }
  .sidebar-placesTree, .sidebar-panel { background: transparent !important; }
  /* новый список вкладок/истории (html) */
  :is(.sidebar-row, sidebar-tab-row, .history-item, fxview-tab-row) { border-radius: 14px !important; }
}

/* ======== ПЛАШКА «ВЫ ПРЕДОСТАВЛЯЕТЕ ДОСТУП К ЭКРАНУ» ========
   Это отдельное маленькое окно браузера (chrome-документ), поэтому стили — здесь,
   в userChrome.css. Делаем капсулу с «живой» красной точкой, как индикатор записи. */
@-moz-document url("chrome://browser/content/webrtcIndicator.xhtml") {
  :root { background: transparent !important; }
  body {
    border-radius: 999px !important;
    border: 1px solid var(--fm-line) !important;
    background: var(--fm-menu, #1c1d20) !important;
    color: var(--fm-ink) !important;
    font: 500 12.5px var(--fm-font) !important;
    padding-inline: 6px 4px !important;
    white-space: nowrap !important;
    box-shadow: none !important;
  }
  .row-item { margin-block: 4px !important; }
  #drag-indicator { opacity: .5 !important; margin-inline: 4px 2px !important; }
  #display-share { gap: 2px !important; }
  /* «живая» точка вместо значка экрана */
  #display-share-icon {
    width: 8px !important; height: 8px !important; margin-inline: 6px 10px !important;
    border-radius: 50% !important; background: #ff453a !important; background-image: none !important;
    box-shadow: 0 0 0 0 rgb(255 69 58 / .6);
    animation: fm-live 1.6s ease-out infinite;
  }
  @keyframes fm-live {
    0% { box-shadow: 0 0 0 0 rgb(255 69 58 / .55); }
    70% { box-shadow: 0 0 0 7px rgb(255 69 58 / 0); }
    100% { box-shadow: 0 0 0 0 rgb(255 69 58 / 0); }
  }
  .stop-button {
    border-radius: 999px !important;
    padding: 3px 12px !important;
    margin-inline-start: 12px !important;
    font-weight: 600 !important;
    background: var(--fm-accent) !important;
    color: var(--fm-on-accent) !important;
  }
  .stop-button:hover { background: color-mix(in srgb, var(--fm-accent) 85%, black) !important; }
  .control-icon, #minimize { border-radius: 999px !important; }
  #minimize { padding: 9px !important; background-color: var(--fm-hover) !important; }
  #minimize:hover { background-color: var(--fm-press) !important; }
  .separator { border-inline-end-color: var(--fm-line) !important; }
}


/* ======================= FLOORP-MODERN END ======================= */
"""

CONTENT = r"""
/* ======================= FLOORP-MODERN BEGIN ======================= */
/* Floorp Modern · One UI — страницы about: (настройки, дополнения, загрузки...) */
@-moz-document url-prefix("about:"), url-prefix("chrome://browser/content/"), url-prefix("chrome://mozapps/"), url-prefix("chrome://global/content/") {
  :root {
@TOKENS@
    /* ---- One UI: чёрный (или светло-серый) фон, белые/графитовые карточки ---- */
    --background-color-canvas: var(--fm-frame) !important;
    --background-color-box: var(--fm-bar) !important;
    --background-color-list-item-hover: var(--fm-hover) !important;
    --text-color: var(--fm-ink) !important;
    --text-color-deemphasized: var(--fm-muted) !important;
    --border-color: var(--fm-line) !important;
    --border-color-deemphasized: var(--fm-line) !important;
    --border-color-interactive: color-mix(in srgb, var(--fm-ink) 28%, transparent) !important;
    --border-color-selected: var(--fm-accent) !important;

    --color-accent-primary: var(--fm-accent) !important;
    --color-accent-primary-hover: color-mix(in srgb, var(--fm-accent) 88%, var(--fm-ink)) !important;
    --color-accent-primary-active: color-mix(in srgb, var(--fm-accent) 76%, var(--fm-ink)) !important;
    --color-accent-primary-selected: color-mix(in srgb, var(--fm-accent) 18%, transparent) !important;
    --focus-outline-color: var(--fm-accent) !important;
    --link-color: var(--fm-accent) !important;
    --link-color-hover: color-mix(in srgb, var(--fm-accent) 85%, var(--fm-ink)) !important;

    --border-radius-xsmall: 6px !important;
    --border-radius-small: 10px !important;
    --border-radius-medium: 16px !important;
    --border-radius-large: 26px !important;
    --border-radius-xlarge: 30px !important;

    /* карточки и группы настроек */
    --card-background-color: var(--fm-bar) !important;
    --card-border: 0 solid transparent !important;
    --card-border-color: transparent !important;
    --card-border-radius: 26px !important;
    --card-box-shadow: none !important;
    --card-box-shadow-hover: none !important;
    --card-padding: 20px !important;
    --box-border: 0 solid transparent !important;
    --box-border-radius: 26px !important;
    --box-border-radius-inner: 18px !important;

    /* кнопки — «таблетки» */
    --button-border-radius: 999px !important;
    --button-min-height: 36px !important;
    --button-padding-inline: 18px !important;
    --button-font-weight: 600 !important;
    --button-background-color: color-mix(in srgb, var(--fm-ink) 9%, transparent) !important;
    --button-background-color-hover: color-mix(in srgb, var(--fm-ink) 14%, transparent) !important;
    --button-background-color-active: color-mix(in srgb, var(--fm-ink) 20%, transparent) !important;
    --button-border-color: transparent !important;
    --button-background-color-primary: var(--fm-accent) !important;
    --button-background-color-primary-hover: color-mix(in srgb, var(--fm-accent) 88%, var(--fm-ink)) !important;
    --button-background-color-primary-active: color-mix(in srgb, var(--fm-accent) 76%, var(--fm-ink)) !important;
    --button-text-color-primary: var(--fm-on-accent) !important;
    --button-text-color-primary-hover: var(--fm-on-accent) !important;
    --button-border-color-primary: transparent !important;

    /* поля ввода и списки */
    --input-text-border-radius: 999px !important;
    --input-search-border-radius: 999px !important;
    --input-text-background-color: var(--fm-field) !important;
    --input-text-border-color: transparent !important;
    --input-text-min-height: 38px !important;
    --select-border-radius: 999px !important;
    --select-background-color: color-mix(in srgb, var(--fm-ink) 9%, transparent) !important;
    --select-border-color: transparent !important;

    /* переключатели в стиле One UI */
    --toggle-background-color-pressed: var(--fm-accent) !important;
    --toggle-background-color-pressed-hover: color-mix(in srgb, var(--fm-accent) 88%, var(--fm-ink)) !important;
    --toggle-border-color: transparent !important;
    --toggle-background-color: color-mix(in srgb, var(--fm-ink) 22%, transparent) !important;
    --toggle-dot-background-color: #fff !important;
    --toggle-height: 22px !important;
    --toggle-width: 40px !important;

    /* навигация слева: «таблетки», выбранный пункт — цвет акцента */
    --page-nav-button-border-radius: 999px !important;
    --page-nav-button-background-color-selected: var(--fm-soft) !important;
    --page-nav-button-text-color-selected: var(--fm-accent) !important;
    --page-nav-button-background-color-hover: var(--fm-hover) !important;
    --page-nav-button-indicator-background-color: transparent !important;
    --page-nav-border-color: transparent !important;

    /* старые переменные страниц */
    --in-content-page-background: var(--fm-frame) !important;
    --in-content-box-background: var(--fm-bar) !important;
    --in-content-primary-button-background: var(--fm-accent) !important;
    --in-content-primary-button-text-color: var(--fm-on-accent) !important;
    --in-content-focus-outline-color: var(--fm-accent) !important;
    --in-content-accent-color: var(--fm-accent) !important;
    --in-content-border-radius: 16px !important;
  }
  :root { background-color: var(--fm-frame) !important; }
  body { font-family: var(--fm-font) !important; }
  h1 { font-weight: 700 !important; letter-spacing: -0.01em !important; }

  /* группы настроек = большие карточки, как в One UI */
  setting-group, groupbox, .card, moz-card, .addon.card, #searchInput + *, .info-box-container {
    border-radius: 26px !important;
  }
  :is(setting-group, groupbox):not([hidden]) {
    background: var(--fm-bar) !important;
    padding: 18px 22px !important;
    margin-block-end: 14px !important;
    border: 0 !important;
  }
  .card, .addon.card { background: var(--fm-bar) !important; border: 0 !important; box-shadow: none !important; }
  .card:hover, .addon.card:hover { box-shadow: none !important; background: color-mix(in srgb, var(--fm-bar) 92%, var(--fm-ink)) !important; }

  /* старые элементы about:addons / about:preferences */
  .category, .page-nav-button { border-radius: 999px !important; }
  .category[selected], .category:is([selected], :hover) { border-radius: 999px !important; }
  .category[selected] { background: var(--fm-soft) !important; color: var(--fm-accent) !important; }
  .category[selected]::before, .category::before { display: none !important; }
  button:not(.ghost-button):not([type="icon"]), select, menulist, input[type="search"], input[type="text"] {
    border-radius: 999px !important;
  }
  input[type="checkbox"] { accent-color: var(--fm-accent) !important; border-radius: 6px !important; }
  input[type="radio"] { accent-color: var(--fm-accent) !important; }
  richlistbox, .list, tree { border-radius: 18px !important; border-color: var(--fm-line) !important; }
  dialog, .dialogBox { border-radius: 26px !important; }
}
/* ---------- стартовая страница Floorp: экран блокировки Galaxy ---------- */
@-moz-document url-prefix("chrome://noraneko-newtab/"), url("about:newtab"), url("about:home") {
  :root {
    --fm-accent: AccentColor;
    --fm-glow: color-mix(in srgb, AccentColor 75%, white);
  }
  html { background: #04050a !important; }
  html, body {
    font-family: "Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif !important;
  }
  body { background: transparent !important; }

  /* живой фон «аврора» в цвете акцента Windows (если не выбрана своя картинка) */
  #root::before {
    content: "";
    position: fixed;
    inset: -15%;
    z-index: -1;
    pointer-events: none;
    background:
      radial-gradient(38% 46% at 22% 28%, color-mix(in srgb, AccentColor 92%, transparent), transparent 70%),
      radial-gradient(34% 42% at 78% 22%, rgb(150 90 255 / .72), transparent 70%),
      radial-gradient(40% 50% at 62% 82%, rgb(0 200 255 / .5), transparent 70%),
      radial-gradient(30% 36% at 18% 86%, rgb(255 80 170 / .38), transparent 70%),
      #04050a;
    /* без filter: blur — на большом слое Firefox рисует вместо него серый блок */
    animation: fm-aurora 38s ease-in-out infinite alternate;
    will-change: transform;
  }
  #root::after {
    /* лёгкое «зерно» и затемнение краёв, как на обоях Galaxy */
    content: "";
    position: fixed;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background: radial-gradient(120% 90% at 50% 40%, transparent 55%, rgb(0 0 0 / .55));
  }
  @keyframes fm-aurora {
    0%   { transform: translate3d(0, 0, 0) rotate(0deg) scale(1); }
    50%  { transform: translate3d(4%, -3%, 0) rotate(8deg) scale(1.08); }
    100% { transform: translate3d(-4%, 3%, 0) rotate(-6deg) scale(1.04); }
  }
  /* новая вкладка Firefox / LibreWolf / Waterfox (Activity Stream): часы в той же
     разметке, что у Floorp, добавляет скрипт просмотрщика; убираем логотип */
  #fm-clock .flex { display: flex !important; align-items: center !important; }
  #fm-clock .flex-col { display: flex !important; }
  #fm-clock { font-family: "Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif !important; color: #fff !important; pointer-events: none !important; }
  :root:has(#fm-clock) :is(.logo-and-wordmark-wrapper, .logo-and-wordmark) { display: none !important; }
  :root:has(#fm-clock) .outer-wrapper { padding-top: 36vh !important; }
  /* встроенные картинки Floorp прячем, свои картинки пользователя остаются */
  .bg-cover[style*="noraneko-newtab"] { display: none !important; }

  /* логотип с тёмной надписью не нужен */
  .flex.justify-center.items-center.mb-8:has(> img[alt="Logo"]) { display: none !important; }

  /* часы: огромные и тонкие, по центру сверху */
  /* раскладка: часы сверху, поиск по центру, ярлыки ниже */
  .w-full.min-h-screen.flex.flex-col.justify-center.items-center {
    padding-top: 16vh !important;
  }
  .absolute.top-4.right-4 {
    position: fixed !important;
    top: 12vh !important;
    left: 50% !important;
    right: auto !important;
    transform: translateX(-50%);
    z-index: 1;
  }
  .absolute.top-4.right-4 > div {
    background: none !important;
    backdrop-filter: none !important;
    box-shadow: none !important;
    padding: 0 !important;
  }
  .absolute.top-4.right-4 > div > .flex {
    flex-direction: column !important;
    align-items: center !important;
    gap: 6px !important;
  }
  .absolute.top-4.right-4 .tabular-nums {
    font-size: clamp(72px, 10.5vw, 156px) !important;
    font-weight: 250 !important;
    line-height: .95 !important;
    letter-spacing: -0.03em !important;
    color: #fff !important;
    text-shadow: 0 6px 40px rgb(0 0 0 / .35), 0 0 60px color-mix(in srgb, AccentColor 35%, transparent);
  }
  .absolute.top-4.right-4 .tabular-nums > .animate-pulse {
    animation: fm-blink 2s ease-in-out infinite !important;
    opacity: .9;
  }
  @keyframes fm-blink { 50% { opacity: .25; } }
  .absolute.top-4.right-4 .flex-col.text-right {
    flex-direction: row !important;
    gap: 8px !important;
    text-align: center !important;
  }
  .absolute.top-4.right-4 .flex-col.text-right > div {
    font-size: 19px !important;
    font-weight: 500 !important;
    color: rgb(255 255 255 / .88) !important;
    letter-spacing: .01em;
  }
  .absolute.top-4.right-4 .flex-col.text-right > div:first-child { text-transform: capitalize; }

  /* поиск: стеклянная «таблетка» */
  .group.cursor-pointer:has(input[readonly]) {
    min-height: 62px !important;
    padding: 0 12px 0 24px !important;
    border-radius: 999px !important;
    background: rgb(22 23 26 / .92) !important;
    border: 1px solid rgb(255 255 255 / .16) !important;
    box-shadow: inset 0 1px 0 rgb(255 255 255 / .25), 0 20px 60px rgb(0 0 0 / .35) !important;
    transition: transform .3s cubic-bezier(.2, .8, .2, 1), background-color .3s ease, box-shadow .3s ease !important;
  }
  .group.cursor-pointer:has(input[readonly]):hover {
    background: rgb(30 31 35 / .96) !important;
    transform: translateY(-2px) scale(1.012);
    box-shadow: inset 0 1px 0 rgb(255 255 255 / .3), 0 26px 70px rgb(0 0 0 / .4), 0 0 0 4px color-mix(in srgb, AccentColor 25%, transparent) !important;
  }
  .group.cursor-pointer:has(input[readonly]) input {
    font-size: 17px !important;
    color: #fff !important;
  }
  .group.cursor-pointer:has(input[readonly]) input::placeholder { color: rgb(255 255 255 / .72) !important; }
  /* Firefox рисует поля и кнопки системным стилем Windows (чёрный прямоугольник),
     пользовательские стили его не отключают — выключаем явно */
  .group.cursor-pointer:has(input[readonly]) :is(input, input:focus, input:hover) {
    appearance: none !important;
    background: transparent !important;
    border: 0 !important;
    box-shadow: none !important;
    outline: none !important;
  }
  button.fixed.bottom-4.right-4 { appearance: none !important; border-radius: 999px !important; }
  .group.cursor-pointer:has(input[readonly]) svg { color: #fff !important; }

  /* ярлыки сайтов: стеклянный «док» с круглыми иконками */
  .inline-block.backdrop-blur-sm.p-3 {
    border-radius: 30px !important;
    background: rgb(22 23 26 / .9) !important;
    border: 1px solid rgb(255 255 255 / .12) !important;
    box-shadow: inset 0 1px 0 rgb(255 255 255 / .18), 0 20px 50px rgb(0 0 0 / .3) !important;
    padding: 14px 10px !important;
  }
  a.group.flex.flex-col.items-center { border-radius: 20px !important; }
  a.group.flex.flex-col.items-center:hover { background: rgb(255 255 255 / .10) !important; }
  a.group .overflow-hidden.bg-gray-700 {
    border-radius: 999px !important;
    background: rgb(255 255 255 / .92) !important;
    box-shadow: inset 0 -2px 4px rgb(0 0 0 / .12), 0 6px 16px rgb(0 0 0 / .3) !important;
  }

  /* кнопка настроек */
  button.fixed.bottom-4.right-4 {
    background: rgb(22 23 26 / .9) !important;
    border: 1px solid rgb(255 255 255 / .12) !important;
  }

  /* ---- обои: свой выбор поверх обоев темы (кнопка слева внизу) ---- */
  #fm-wall { position: fixed; inset: 0; z-index: -1; pointer-events: none; display: none; }
  #fm-wall-shade { position: absolute; inset: 0; background: #000; opacity: .15; }
  :root[fm-wall] #fm-wall { display: block; animation: fm-wall-in calc(.7s * var(--fm-k)) var(--fm-ease) both; }
  @keyframes fm-wall-in { from { opacity: 0; scale: 1.06; } }
  :root[fm-wall] { background: #000 !important; }
  :root[fm-wall] body { background: transparent !important; background-image: none !important; }
  :root[fm-wall] #root::before { display: none !important; }
  :root[fm-wall] .bg-cover { display: none !important; }

  #fm-wall-btn {
    position: fixed; left: 16px; bottom: 16px; z-index: 50;
    width: 40px; height: 40px; border-radius: 999px; cursor: pointer;
    display: grid; place-items: center;
    background: rgb(22 23 26 / .62) center / 18px no-repeat url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><rect x='3' y='4' width='18' height='16' rx='4'/><circle cx='9' cy='10' r='1.8'/><path d='M4 17l5-5 4 4 2.5-2.5L20 18'/></svg>");
    border: 1px solid rgb(255 255 255 / .16);
    box-shadow: inset 0 1px 0 rgb(255 255 255 / .2), 0 8px 24px rgb(0 0 0 / .3);
    backdrop-filter: blur(18px) saturate(1.6);
    transition: scale calc(.35s * var(--fm-k)) var(--fm-spring), background-color .2s ease;
  }
  #fm-wall-btn:hover { scale: 1.1; background-color: rgb(40 41 46 / .75); }
  #fm-wall-btn:active { scale: .9; }
  #fm-wall-btn[open] { background-color: color-mix(in srgb, AccentColor 60%, rgb(22 23 26)); }

  #fm-wall-pop {
    position: fixed; left: 16px; bottom: 66px; z-index: 51;
    width: 336px; box-sizing: border-box; padding: 14px;
    border-radius: 26px; color: #fff;
    font: 500 13px "Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif;
    background: rgb(24 25 29 / .82);
    border: 1px solid rgb(255 255 255 / .14);
    box-shadow: inset 0 1px 0 rgb(255 255 255 / .18), 0 24px 60px rgb(0 0 0 / .45);
    backdrop-filter: blur(28px) saturate(1.7);
    transform-origin: 0 100%;
    animation: fm-wall-pop calc(.42s * var(--fm-k)) var(--fm-spring) both;
  }
  #fm-wall-pop[hidden] { display: none !important; }
  @keyframes fm-wall-pop { from { opacity: 0; translate: 0 10px; scale: .86; } }
  #fm-wall-pop .fm-wall-title { font-size: 15px; font-weight: 700; margin: 2px 4px 10px; }
  #fm-wall-pop .fm-wall-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
  #fm-wall-pop .fm-wall-sw {
    position: relative; height: 54px; border-radius: 14px; cursor: pointer; overflow: hidden;
    background-color: #2a2b30; outline: 2px solid transparent; outline-offset: 2px;
    box-shadow: inset 0 0 0 1px rgb(255 255 255 / .12);
    transition: scale calc(.3s * var(--fm-k)) var(--fm-spring), outline-color .2s ease;
    animation: fm-nt-pop calc(.5s * var(--fm-k)) var(--fm-spring) both;
  }
  #fm-wall-pop .fm-wall-sw:nth-child(n+5) { animation-delay: .04s; }
  #fm-wall-pop .fm-wall-sw:nth-child(n+9) { animation-delay: .08s; }
  #fm-wall-pop .fm-wall-sw:hover { scale: 1.06; }
  #fm-wall-pop .fm-wall-sw:active { scale: .92; }
  #fm-wall-pop .fm-wall-sw[selected] { outline-color: color-mix(in srgb, AccentColor 70%, white); }
  #fm-wall-pop .fm-wall-cap {
    position: absolute; inset: auto 0 0 0; padding: 10px 6px 4px;
    font-size: 11px; font-weight: 600; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    background: linear-gradient(transparent, rgb(0 0 0 / .55));
  }
  #fm-wall-pop .fm-wall-theme { background: repeating-linear-gradient(135deg, #2a2b30 0 8px, #33343a 8px 16px); }
  #fm-wall-pop .fm-wall-own:not([style*="url("]) {
    background: #2a2b30 center 14px / 18px no-repeat url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round'><path d='M12 5v14M5 12h14'/></svg>");
  }
  #fm-wall-pop .fm-wall-own[busy] { opacity: .5; }
  #fm-wall-pop .fm-wall-dim { display: flex; align-items: center; gap: 12px; margin: 12px 4px 2px; color: rgb(255 255 255 / .8); }
  #fm-wall-pop .fm-wall-dim input { flex: 1; accent-color: color-mix(in srgb, AccentColor 70%, white); }
  #fm-wall-pop .fm-wall-more {
    margin: 10px 0 0; padding: 9px 12px; border-radius: 14px; cursor: pointer; text-align: center; font-weight: 600;
    background: rgb(255 255 255 / .08); transition: background-color .2s ease, scale calc(.3s * var(--fm-k)) var(--fm-spring);
  }
  #fm-wall-pop .fm-wall-more:hover { background: rgb(255 255 255 / .14); }
  #fm-wall-pop .fm-wall-more:active { scale: .96; }

  /* ---- плавность: часы, поиск и ярлыки выплывают по очереди, как на экране блокировки ---- */
  :root {
    --fm-spring: cubic-bezier(.2, .9, .25, 1.15);
    --fm-ease: cubic-bezier(.2, .8, .2, 1);
    --fm-k: 1;
  }
  .absolute.top-4.right-4 > div { animation: fm-nt-clock calc(1s * var(--fm-k)) var(--fm-ease) both; }
  @keyframes fm-nt-clock { from { opacity: 0; translate: 0 26px; scale: .9; filter: blur(14px); } }
  :is(.group.cursor-pointer:has(input[readonly]), .search-wrapper .search-inner-wrapper) {
    animation: fm-nt-in calc(.9s * var(--fm-k)) var(--fm-spring) .12s both;
  }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > * { animation: fm-nt-pop calc(.7s * var(--fm-k)) var(--fm-spring) both; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(1) { animation-delay: .22s; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(2) { animation-delay: .26s; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(3) { animation-delay: .30s; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(4) { animation-delay: .34s; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(5) { animation-delay: .38s; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(6) { animation-delay: .42s; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(7) { animation-delay: .46s; }
  :is(.inline-block.backdrop-blur-sm.p-3, .top-sites-list) > :nth-child(n+8) { animation-delay: .5s; }
  @keyframes fm-nt-in { from { opacity: 0; translate: 0 22px; scale: .94; } }
  @keyframes fm-nt-pop { from { opacity: 0; translate: 0 16px; scale: .7; } }
  /* ярлыки приподнимаются под курсором и пружинят при нажатии */
  :is(a.group.flex.flex-col.items-center, .top-site-outer .top-site-button) {
    transition: translate calc(.4s * var(--fm-k)) var(--fm-spring), scale calc(.4s * var(--fm-k)) var(--fm-spring), background-color .2s ease !important;
  }
  :is(a.group.flex.flex-col.items-center, .top-site-outer .top-site-button):hover { translate: 0 -5px; scale: 1.04; }
  :is(a.group.flex.flex-col.items-center, .top-site-outer .top-site-button):active { scale: .9; }
  .weather-widget, .widgets-wrapper { animation: fm-nt-in calc(.9s * var(--fm-k)) var(--fm-spring) .3s both; }

  @media (max-height: 640px) {
    .absolute.top-4.right-4 { top: 6vh !important; }
    .absolute.top-4.right-4 .tabular-nums { font-size: 64px !important; }
  }
  @media (prefers-reduced-motion: reduce) {
    #root::before, .animate-pulse, .absolute.top-4.right-4 > div, .weather-widget, .widgets-wrapper,
    .group.cursor-pointer, .search-inner-wrapper, .inline-block.backdrop-blur-sm.p-3 > *, .top-sites-list > * { animation: none !important; }
  }
}

/* ---------- скриншот страницы (Ctrl+Shift+S): панель и рамка в стиле One UI ---------- */
#screenshots-component {
  --fm-shot-accent: AccentColor;
  font: 500 13px "Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif !important;
}
#screenshots-component #buttons-container {
  padding: 6px !important;
  border-radius: 999px !important;
  background: #17181a !important;
  color: #f2f2f3 !important;
  border: 1px solid rgb(255 255 255 / .1) !important;
  box-shadow: 0 12px 34px rgb(0 0 0 / .45) !important;
}
#screenshots-component .screenshots-button {
  min-height: 38px !important;
  padding: 0 16px !important;
  margin-inline: 3px !important;
  border: 0 !important;
  border-radius: 999px !important;
  background: rgb(255 255 255 / .09) !important;
  color: #f2f2f3 !important;
  font: inherit !important;
  outline: none !important;
  box-shadow: none !important;
  transition: background-color .15s ease, scale .2s cubic-bezier(.3, 1.6, .5, 1) !important;
}
#screenshots-component .screenshots-button:hover { background: rgb(255 255 255 / .16) !important; }
#screenshots-component .screenshots-button:active { scale: .94; }
#screenshots-component .screenshots-button:focus-visible { outline: 2px solid var(--fm-shot-accent) !important; outline-offset: 2px !important; }
#screenshots-component #cancel { width: 38px !important; min-width: 38px !important; padding: 0 !important; }
#screenshots-component #download {
  background: var(--fm-shot-accent) !important;
  color: AccentColorText !important;
  font-weight: 600 !important;
}
#screenshots-component #download:hover { background: color-mix(in srgb, var(--fm-shot-accent) 85%, white) !important; }
#screenshots-component #selection-size {
  padding: 4px 12px !important;
  border-radius: 999px !important;
  border: 1px solid rgb(255 255 255 / .1) !important;
  background: #17181a !important;
  color: #f2f2f3 !important;
  font: 600 12px "Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif !important;
  font-variant-numeric: tabular-nums !important;
}
#screenshots-component .highlight {
  border: 2px solid rgb(255 255 255 / .95) !important;
  border-radius: 6px !important;
  box-shadow: 0 0 0 1px rgb(0 0 0 / .25), 0 0 24px rgb(0 0 0 / .25) !important;
}
#screenshots-component #hover-highlight {
  border: 2px solid var(--fm-shot-accent) !important;
  border-radius: 8px !important;
  background: color-mix(in srgb, var(--fm-shot-accent) 16%, transparent) !important;
}
#screenshots-component .mover {
  background: #fff !important;
  box-shadow: 0 0 0 3px var(--fm-shot-accent), 0 2px 8px rgb(0 0 0 / .45) !important;
}
#screenshots-component #screenshots-cancel-button {
  border-radius: 999px !important;
  padding: 8px 20px !important;
  border: 1px solid rgb(255 255 255 / .7) !important;
  background: rgb(0 0 0 / .25) !important;
}
#screenshots-component #screenshots-cancel-button:hover { background: #fff !important; color: #000 !important; }
#screenshots-component .preview-instructions { font: 600 22px "Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif !important; }

/* ---------- настройки Floorp (chrome://noraneko-settings) в стиле One UI ---------- */
@-moz-document url-prefix("chrome://noraneko-settings/") {
  :root, :root[data-theme], .floorp-standard-ui {
    --floorp-brand: AccentColor !important;
    --floorp-brand-hover: color-mix(in srgb, AccentColor 85%, black) !important;
    --floorp-action: AccentColor !important;
    --floorp-focus: AccentColor !important;
    --floorp-switch-on: AccentColor !important;
    --floorp-font: "Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif !important;
    --chakra-colors-purple-solid: AccentColor !important;
    --chakra-colors-purple-fg: AccentColor !important;
    --chakra-colors-purple-contrast: AccentColorText !important;
    --chakra-colors-purple-focus-ring: AccentColor !important;
    --chakra-colors-purple-subtle: color-mix(in srgb, AccentColor 14%, transparent) !important;
    --chakra-colors-purple-muted: color-mix(in srgb, AccentColor 24%, transparent) !important;
    --chakra-colors-purple-emphasized: color-mix(in srgb, AccentColor 34%, transparent) !important;
    --chakra-radii-l1: 10px !important;
    --chakra-radii-l2: 14px !important;
    --chakra-radii-l3: 22px !important;
    --chakra-radii-sm: 8px !important;
    --chakra-radii-md: 12px !important;
    --chakra-radii-lg: 18px !important;
    --chakra-radii-xl: 22px !important;
    --chakra-radii-2xl: 26px !important;
    --chakra-fonts-body: var(--floorp-font) !important;
    --chakra-fonts-heading: var(--floorp-font) !important;
  }
  @media (prefers-color-scheme: dark) {
    :root, :root[data-theme], .floorp-standard-ui {
      --floorp-action: color-mix(in srgb, AccentColor 62%, white) !important;
      --floorp-canvas: #000 !important;
      --floorp-subtle: #17181a !important;
      --floorp-surface: #17181a !important;
      --floorp-line: rgb(255 255 255 / .08) !important;
      --chakra-colors-bg: #000 !important;
      --chakra-colors-bg-muted: #17181a !important;
      --chakra-colors-bg-panel: #17181a !important;
      --chakra-colors-bg-subtle: #17181a !important;
      --chakra-colors-border: rgb(255 255 255 / .08) !important;
      --chakra-colors-purple-fg: color-mix(in srgb, AccentColor 62%, white) !important;
    }
  }
  @media (prefers-color-scheme: light) {
    :root, :root[data-theme], .floorp-standard-ui {
      --floorp-canvas: #f2f3f5 !important;
      --floorp-subtle: #fff !important;
      --floorp-surface: #fff !important;
      --floorp-line: rgb(0 0 0 / .07) !important;
      --chakra-colors-bg: #f2f3f5 !important;
      --chakra-colors-bg-muted: #fff !important;
      --chakra-colors-bg-panel: #fff !important;
      --chakra-colors-border: rgb(0 0 0 / .07) !important;
    }
  }
  body { font-family: var(--floorp-font) !important; }
  button, input, select, textarea { font-family: inherit !important; }
}


/* ======== ПАНЕЛИ ЗАКЛАДОК И ЖУРНАЛА (старое «дерево» Firefox) ======== */
@-moz-document url-prefix("chrome://browser/content/places/"), url-prefix("chrome://browser/content/sidebar/"), url-prefix("chrome://browser/content/bookmarks/"), url-prefix("chrome://browser/content/history/") {
  :root, body, #bookmarksPanel, #history-panel, page, window {
    background-color: var(--fm-frame, light-dark(#f2f3f5, #000)) !important;
    color: var(--fm-ink, light-dark(#111214, #f2f2f3)) !important;
    font-family: "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif !important;
  }
  #sidebar-search-container, .sidebar-search-container {
    padding: 10px 12px 8px !important;
    background: transparent !important;
  }
  :is(search-textbox, moz-input-search, input[type="search"], #search-box) {
    border-radius: 999px !important;
    border: 0 !important;
    background-color: color-mix(in srgb, currentColor 9%, transparent) !important;
    min-height: 36px !important;
    padding-inline: 12px !important;
    outline: none !important;
  }
  :is(search-textbox, moz-input-search, input[type="search"], #search-box):focus-within {
    outline: 2px solid var(--fm-accent, AccentColor) !important;
    outline-offset: -2px !important;
  }
  tree, #bookmarks-view, #historyTree {
    background-color: transparent !important;
    border: 0 !important;
    color: inherit !important;
    margin: 0 6px !important;
    appearance: none !important;
  }
  tree:focus-visible { outline: none !important; }
  treechildren::-moz-tree-row {
    min-height: 36px !important;
    background-color: transparent !important;
    border: 0 !important;
  }
  treechildren::-moz-tree-row(hover) {
    background-color: color-mix(in srgb, currentColor 7%, transparent) !important;
  }
  treechildren::-moz-tree-row(selected),
  treechildren::-moz-tree-row(selected, focus),
  treechildren::-moz-tree-row(selected, current, focus) {
    background-color: color-mix(in srgb, var(--fm-accent, AccentColor) 16%, transparent) !important;
    border: 0 !important;
    outline: none !important;
  }
  treechildren::-moz-tree-row(current, focus) { outline: none !important; border: 0 !important; }
  treechildren::-moz-tree-cell-text {
    color: inherit !important;
    padding-inline-start: 6px !important;
    font-size: 13.5px !important;
  }
  treechildren::-moz-tree-cell-text(selected),
  treechildren::-moz-tree-cell-text(selected, focus) {
    color: var(--fm-ink, light-dark(#111214, #f2f2f3)) !important;
    font-weight: 600 !important;
  }
  treechildren::-moz-tree-twisty { padding-inline: 6px !important; opacity: .7; }
  treechildren::-moz-tree-image { margin-inline-end: 4px !important; }
  .sidebar-placesTree, .sidebar-panel { background: transparent !important; }
  /* новый список вкладок/истории (html) */
  :is(.sidebar-row, sidebar-tab-row, .history-item, fxview-tab-row) { border-radius: 14px !important; }
}
/* ======================= FLOORP-MODERN END ======================= */
"""

chrome_css = CHROME.replace("@TOKENS@", TOKENS).replace("@ICONS@", icon_rules)
content_css = CONTENT.replace("@TOKENS@", TOKENS.replace("\n  ", "\n    "))

# Цвет акцента можно переопределить в установщике: везде, где стоит системный
# AccentColor, сначала берётся --fm-user-accent (если он задан).
import re as _re
def _user_accent(css):
    css = css.replace("AccentColorText", "var(--fm-user-on-accent, AccentColorText)")
    return _re.sub(r"\bAccentColor\b(?!Text)", "var(--fm-user-accent, AccentColor)", css)
chrome_css = _user_accent(chrome_css)
content_css = _user_accent(content_css)

if __name__ == "__main__":
    import sys, pathlib
    out = pathlib.Path(sys.argv[1])
    (out / "floorp-modern-chrome.css").write_text(chrome_css, encoding="utf-8")
    (out / "floorp-modern-content.css").write_text(content_css, encoding="utf-8")
    print("ok")
